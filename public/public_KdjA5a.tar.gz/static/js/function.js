;var vtbcm = '__0x5a96d'
  , __0x5a96d = ['w6XCuHI=', 'w4PCkh7CjB4=', 'QcOPWksf', 'w5jDvVUC', 'w6g8FA==', 'DF4tWMO6SWU=', 'ecOKAGTDqcKLfMOyHcOVwqDCtQ==', 'PwDDqcKo', 'wpvCpcKcwohKeMOlfg/DiBpSA2fClQ==', 'wq3DiX81w6REMCIu', '5Lij5q+K5a2U56Cv6L6j5YeP5LuX5LuF6IWT77+Q6K+g6YSu5pe46Lyw5YW+772T', 'CcO9Q1A=', 'wqbCksKCGcKncMOMVMOKwr7DoG4+w4Q1w5UofcKFCz7Ch2nDvHrDqcKpwrrCtsKmw4TCi8OxDSzCt8OLw77Cqg==', 'wqjClMKZBMOCK8KaU8OY', 'NMO/U0zDog==', 'eBM5w5DCgg==', 'w5nCnxE=', 'w4TDgMK2w5E=', 'w7pIUR58', 'w43Clk/DpcOY', 'ccOIwqnDnUI=', 'VcO7wrXDom4vHg==', 'w4vCqMO5w4DDjg==', 'YxUZ', 'L8O7VA==', '55eC5ouO5ZOY5bWb6KCO5rK35YSI772a6K2t5oyv5Lig55a75oiT5ZCCRQ==', 'wonDuzI=', 'w5/DsEgALw==', 'wo1Mw4/CuF0=', 'w67DtMOr', 'B8OBBl0=', 'w7XDpcKEw70=', 'fD5sU8KJCsOk', 'wq/DqFwJ', 'Y2JEw53Dgg==', 'w7jCunfDlsOJ', 'w6Mpw6XCihg=', 'w4/DqFMKKmfDk8O7bw==', 'XsKlwqLDtcKt', 'wrHDmynCgx0=', 'f8OpIQ==', 'w6DDo8KKw6BN', '5LiP6IK45YiR6ZivwrfCkyVqawQxw6vDpg==', 'w5LDhUXDs8OR', 'w73CjsKUwqpH', 'w6/Di1MgJg==', 'XBDDjU58w5k+HS/CssKbLsKsDw==', 'FMOQBsOr', 'w4XCjMOnw6DDnQ==', 'Pl4df8Oj', 'woNWw7LCjWDCk8OA', 'VMOswq7Dhg==', 'eMOdG1vDk8KMYMOsDA==', 'd8KNwobDiA==', 'woIfw7VISw==', 'woI3w5l9ZQ==', 'fcKQworDhMKcw5o+Fg==', 'w5zCix/Cpx0T', 'BcOHDkbDgg==', 'wpTCjFPDocOlwpojw5DCu07DlMOSw4ZrGA==', 'wq3DlXEhw75dACArS2LDhyfCm8Kk', 'X8OZLg==', '6K2q5YWL5q2n56Cg6Lyn5YaQ55WB5ous5ZC65ZOr5ay856GJ', 'AcO9aFE=', 'w4HDo3gKw7Q=', 'w5bCg8KCO8Ka', 'Z8KewoU=', 'w58JA2RG', 'X8OxRX89', 'ccO3wqnDk3U=', 'EcOuaw==', 'wqteG8KLHg==', 'w7TCocKj', 'woRBw6/Co3PCk8Of', 'XAh1e8K5', 'w4nDsXY7IA==', 'w4TCswTCmTE=', 'wo1Xw4PCsg==', 'woDCrcK7w5HDtQ==', 'MsKTwobDgsKBw50OCMK3wptOw5A+Zjs=', '55eE5oiK5ZKv5ouc5a+K56Km6ZaJ6KyG776z', 'GlA8UMOLW298L2xTAAoVw48L', 'eg7Dq8K7w53Dr8O1wpHDkgggM8OFwq7Dr8OoUMOSwoA=', 'XSojw4XCvxNDA1s2wpDClA5sw5LClBnDv0VTw6o=', 'eg7Dq8K7w53Dr8O1wpHDkgggM8OFwq7Dr8OoUMOLwpbDqsOYPQHDkcKSMcOkwojDnQ==', 'SMKQWw==', 'wq3DoF4CQg==', 'w5fDrmc=', 'cA7Dvg==', 'WRUp', 'ICrDuBU=', 'w7didjTDlg==', 'w4nCkcOCw7LDuQ==', 'w4kWw4/CsTc=', 'UR0KK8Ka', 'w4fCqcKtHsKd', 'w58Tw4nCmsKE', 'FQvDgw3CmQ==', 'WTwILsK7', 'Uh0JM8Kt', 'wr/CnMKaw4XDkQ==', 'w5nCgVHDow==', 'w5jCjmDCqXo=', 'WSMZw5TClg==', 'CMOWCcOrZg==', 'QsOpwq3DjGI=', 'fsKZw5VNaA==', 'w4fCklPDvsO1wqsaw4rCp1/Dg8OO', 'w60Ow7Q=', 'E0vDocKQBw==', 'w7wUw4zChMK9', 'Ew3Djw==', 'w6LDlnk=', 'wpjCnMK0w43DnAzDsDrDrig=', 'NcOddw==', 'w5rDs8OUfGIa', 'w4vCvmrDkF4=', 'w54VFH9z', 'w7pddAJ9w7/DjcO6PQ==', 'w4TChU/DtcOlwpsSw7bCvETDlMOdw4Bj', 'w69maSHDgsKQIMKvUgo=', 'QsKRb8O4w5LClsO8QnICTg==', 'EQbDug==', 'w5LCllnDqMO4', 'w6diwr3Ds8OU', 'w5nDtHTDlsOsbQ==', 'BiLDlRgt', 'aMO0wrbDn3U=', 'E1ElVsOXTGhqMw==', 'aMKFw7lLScOfwqo=', 'SsOqwpk=', 'w7pddAJ9w78=', 'TsKebsO7w4LClw==', 'w7vCj1fCoFc=', 'wrlTw7vCmG0=', 'w5vDosOSYH4TQ8ODwoB/Xg==', 'w6/Cu0TCn2c=', 'w5zCig/CvQcGw4MMwoQ=', 'w5I7w6/Ciz/Cog5VPcO7w5vDqhnDpw==', 'KsOXZE0XQsK3', 'w7zDnGozw6VdCTEmTXQ=', 'biF2TMKPF8K+CsOo', 'VBYrMsKN', '5Lii6IOa5Yiq6ZuRw5oVPMObfQ3CpE7Dhw==', 'wpMSw49P', 'w4LDhcKww4bDqijCnCw4L8Kz', 'w6nDoMKcw6Y=', 'XBQqJcKBw4Z8', '5rSa6Iu46Iqy5bWx5L+35a6X54iT5p+o5oit5p+877yG55iJ54m05Li556uE77y55b+Y6Ly456iP5rOu5b6b6LS15Lms776e', '5pW36Z+G6LWA54q4', '5pWX5bqf5ZG2', '572T6aCw5ZC95qyu5piw5pWM', '5ZyC57ij5pum5paX', '6K2H5L2r6La95Yyd5a+B56O3', '6L+K5ZmxW+WIgeaUvA==', '5Yyj55mi57q46K2b', 'eCF+WsKB', '5pWF6Z6q5L+W5Lqz6K2B5Lin', '5LqM55eV5Lq95pyiw4pDK8O4GcKaeMK7', 'w6tYdiJ2', 'fcK6wq7Dg8KM', 'w6ZtTidC', 'w7rChWjDq8O4', '5YiZ5L275Zu05qKy', 'wqVew7PCoVQ=', 'w4pswo3Dm8Oe', '5rSz6Ke35Zim5Ya25qKW', 'w7/Dmk43w68=', 'wpVaK8K1PQ==', 'w6wQw5bCthI=', '5ouE5Lu+5oiW', 'w5nDi8Kfw759', 'wqPDpl4NXA==', 'w7ANw58=', '6KyM5YWz5qy856KK6L+P5YaD55W65oqk5ZOL5ZKT5ayF56K/', 'SijDlcK+w58=', 'EhbDnw==', 'w7kYw7zCkcKFDhVo', 'w6HCtiTCshM=', 'dMKCw7BCWcOEwr3Ctg==', 'w5NLXSjDjg==', 'QcObwrDDhm4=', 'woTCo8KMLsOV', 'bcOHG0E=', 'w7LClMOVw7jDgl08w5g=', 'w4fCignCpFNOwoUdwopsF8OqAMOWw5XCuXLCmcOnwojDlB4/w4NZRMOgwoDChQLDt8KKwq7DmMKfw7sNwq4=', 'U8O0wqDDkw==', 'w7bCiE0=', 'wqLCj8OSw7PDgkAvw44fwrhlwrpdwqo=', 'LCleLMKtwpICdmALcw==', 'WHVcw4XDpQ==', 'HcOncVAS', 'w53DrFEPLXPDjg==', 'w4vCnwnCtQ==', 'wohTMMKTA8KKPcOywqJ2wq3DmQ==', '5rCm5YWq5oum5Yu2', 'woTDgXA9YA==', 'w6nDpsKLw7c=', 'w4huTx3DjA==', 'RsOswqjDjH0vAQ==', 'w4Yuw4nCqTk=', 'TC7DisKM', 'A8O6w4XChkEMwqjDrWHDh8OSI8KNGSnDhGXDp8KTw7TDujjDgMOHw64xwqfCs8Ktw5nDpsOxDzDDssK8AMKFw7TCuhfCuFMRVHA=', 'QsOoZldjFQ3Ci8O/NcOzw5VtwqpOanFnbMKowqUjwqxDe8OBBgkrWm1mw67CrcKqPcOERwdsw4TChiZGwrXCvw==', 'ZsKBw7NW', 'w5PCtsKzMcKW', '5Lmn5q2k5a2a56Gx6L+G5YWA5LiD5Liq6IaS77+l6Kyx6YSa5pWs6L6r5YWo772w', 'bsOba30h', 'S8KAw5k=', 'wpFjw7XCqHM=', 'Wi8ww54=', 'w7/DsXnDmsOL', 'HB/DqSjCkg==', 'HgjDiVE=', 'TsOgJ2I=', 'FxbDnFkvwoVlDyrCiMOaLcKiBGTDgcKywpDCn8KqTcOFB15mfcK/QcOgZMKdwr1ITEXDpMKQw6rDpTPDocKPLl87Lw=='];
(function(_0x25738b, _0x5d6358) {
    var _0x5c809a = function(_0x117fbf) {
        while (--_0x117fbf) {
            _0x25738b['push'](_0x25738b['shift']());
        }
    };
    _0x5c809a(++_0x5d6358);
}(__0x5a96d, 0x90));
var _0x3a95 = function(_0xa88cf7, _0x51ab6f) {
    _0xa88cf7 = _0xa88cf7 - 0x0;
    var _0x59a7ba = __0x5a96d[_0xa88cf7];
    if (_0x3a95['initialized'] === undefined) {
        (function() {
            var _0x1d9fb3 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x35025a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x1d9fb3['atob'] || (_0x1d9fb3['atob'] = function(_0x5f53a9) {
                var _0x912492 = String(_0x5f53a9)['replace'](/=+$/, '');
                for (var _0x320235 = 0x0, _0x107e7e, _0x2f8c31, _0x54c7c2 = 0x0, _0xdcce7a = ''; _0x2f8c31 = _0x912492['charAt'](_0x54c7c2++); ~_0x2f8c31 && (_0x107e7e = _0x320235 % 0x4 ? _0x107e7e * 0x40 + _0x2f8c31 : _0x2f8c31,
                _0x320235++ % 0x4) ? _0xdcce7a += String['fromCharCode'](0xff & _0x107e7e >> (-0x2 * _0x320235 & 0x6)) : 0x0) {
                    _0x2f8c31 = _0x35025a['indexOf'](_0x2f8c31);
                }
                return _0xdcce7a;
            }
            );
        }());
        var _0x358618 = function(_0x2e2acf, _0x5869ee) {
            var _0x5e91b3 = [], _0x109417 = 0x0, _0x1cd8a8, _0x12608c = '', _0x53493e = '';
            _0x2e2acf = atob(_0x2e2acf);
            for (var _0x456329 = 0x0, _0x31b669 = _0x2e2acf['length']; _0x456329 < _0x31b669; _0x456329++) {
                _0x53493e += '%' + ('00' + _0x2e2acf['charCodeAt'](_0x456329)['toString'](0x10))['slice'](-0x2);
            }
            _0x2e2acf = decodeURIComponent(_0x53493e);
            for (var _0x227cf3 = 0x0; _0x227cf3 < 0x100; _0x227cf3++) {
                _0x5e91b3[_0x227cf3] = _0x227cf3;
            }
            for (_0x227cf3 = 0x0; _0x227cf3 < 0x100; _0x227cf3++) {
                _0x109417 = (_0x109417 + _0x5e91b3[_0x227cf3] + _0x5869ee['charCodeAt'](_0x227cf3 % _0x5869ee['length'])) % 0x100;
                _0x1cd8a8 = _0x5e91b3[_0x227cf3];
                _0x5e91b3[_0x227cf3] = _0x5e91b3[_0x109417];
                _0x5e91b3[_0x109417] = _0x1cd8a8;
            }
            _0x227cf3 = 0x0;
            _0x109417 = 0x0;
            for (var _0x39e85d = 0x0; _0x39e85d < _0x2e2acf['length']; _0x39e85d++) {
                _0x227cf3 = (_0x227cf3 + 0x1) % 0x100;
                _0x109417 = (_0x109417 + _0x5e91b3[_0x227cf3]) % 0x100;
                _0x1cd8a8 = _0x5e91b3[_0x227cf3];
                _0x5e91b3[_0x227cf3] = _0x5e91b3[_0x109417];
                _0x5e91b3[_0x109417] = _0x1cd8a8;
                _0x12608c += String['fromCharCode'](_0x2e2acf['charCodeAt'](_0x39e85d) ^ _0x5e91b3[(_0x5e91b3[_0x227cf3] + _0x5e91b3[_0x109417]) % 0x100]);
            }
            return _0x12608c;
        };
        _0x3a95['rc4'] = _0x358618;
        _0x3a95['data'] = {};
        _0x3a95['initialized'] = !![];
    }
    var _0x4c4abc = _0x3a95['data'][_0xa88cf7];
    if (_0x4c4abc === undefined) {
        if (_0x3a95['once'] === undefined) {
            _0x3a95['once'] = !![];
        }
        _0x59a7ba = _0x3a95['rc4'](_0x59a7ba, _0x51ab6f);
        _0x3a95['data'][_0xa88cf7] = _0x59a7ba;
    } else {
        _0x59a7ba = _0x4c4abc;
    }
    return _0x59a7ba;
};
/*if (location[_0x3a95('0x0', 'uHsL')]['indexOf'](_0x3a95('0x1', 'ye29')) == -0x1 && location[_0x3a95('0x2', '^kc%')][_0x3a95('0x3', 'n]!E')]('tao-jiujiu.com') == -0x1) {
    while (!![]) {
        alert(_0x3a95('0x4', 'IdL2'));
    }
}*/
var Encapsulation = {
    'template': '#encapsulation',
    'data': function() {
        var _0x5277dc = {
            'eobea': _0x3a95('0x5', 'V[T$'),
            'oDHLQ': _0x3a95('0x6', 'eA]R'),
            'YCLHM': _0x3a95('0x7', '$LpG'),
            'bqpIe': _0x3a95('0x8', 'VtQ$'),
            'lEGfd': '视频全屏',
            'PjxCR': '微信分享',
            'MeTmt': _0x3a95('0x9', 'R)sU'),
            'IcQkX': '清除缓存',
            'DAWgg': '消息推送',
            'qcPqx': _0x3a95('0xa', 'e3Q('),
            'natQa': _0x3a95('0xb', 'NCYy'),
            'MNJND': '浏览器UA'
        };
        return {
            'msg1': [{
                'text': [_0x5277dc[_0x3a95('0xc', '[cyM')], _0x3a95('0xd', 'ye29'), _0x3a95('0xe', 'IdL2')]
            }, {
                'text': ['界面全屏', _0x5277dc['oDHLQ'], _0x5277dc['YCLHM']]
            }],
            'msg2': [{
                'text': _0x5277dc[_0x3a95('0xf', '[s0D')],
                'hot': !![]
            }, {
                'text': _0x5277dc[_0x3a95('0x10', 'kd36')],
                'hot': !![]
            }, {
                'text': _0x5277dc[_0x3a95('0x11', '[s0D')],
                'hot': ![]
            }, {
                'text': _0x5277dc['PjxCR'],
                'hot': !![]
            }, {
                'text': _0x5277dc[_0x3a95('0x12', 'eA]R')],
                'hot': !![]
            }, {
                'text': _0x3a95('0x13', 'w9aA'),
                'hot': ![]
            }, {
                'text': _0x5277dc[_0x3a95('0x14', 'r@Vr')],
                'hot': ![]
            }, {
                'text': _0x5277dc[_0x3a95('0x15', 'ym77')],
                'hot': !![]
            }, {
                'text': _0x3a95('0x16', 'KCbE'),
                'hot': ![]
            }, {
                'text': _0x5277dc[_0x3a95('0x17', 'RyDa')],
                'hot': ![]
            }, {
                'text': '导航',
                'hot': ![]
            }, {
                'text': '侧边栏',
                'hot': ![]
            }, {
                'text': _0x5277dc[_0x3a95('0x18', 'wvok')],
                'hot': ![]
            }, {
                'text': _0x5277dc[_0x3a95('0x19', 'V#wN')],
                'hot': ![]
            }, {
                'text': _0x3a95('0x1a', 'OJ2t'),
                'hot': !![]
            }, {
                'text': '更多',
                'hot': ![]
            }],
            'show_loading': !![],
            'applist': [],
            'packPrice': '',
            'doclist_0': [],
            'doclist_1': [],
            'doclist_2': [],
            'artical': {}
        };
    },
    'methods': {
        'packTab': function() {
            var _0x5e9228 = {
                'XDplD': function _0xd0fa5a(_0x37247a, _0x14b1f3) {
                    return _0x37247a(_0x14b1f3);
                },
                'hbCim': '.good-case\x20.g-con\x20.tab-list\x20li'
            };
            _0x5e9228[_0x3a95('0x1b', '^kc%')]($, _0x5e9228['hbCim'])[_0x3a95('0x1c', 'AKzo')](function() {
                var _0xe08efa = {
                    'rEJkr': function _0x4c68c9(_0x326556, _0x3fb904) {
                        return _0x326556 === _0x3fb904;
                    },
                    'VILfg': _0x3a95('0x1d', 'V#wN'),
                    'sEqmt': function _0x16f97a(_0x3af91f, _0x1a33b6) {
                        return _0x3af91f(_0x1a33b6);
                    },
                    'NHYfz': 'active',
                    'JEzGH': '.good-case\x20.tab-con\x20ul',
                    'zyEbb': _0x3a95('0x1e', 'wvok')
                };
                if (_0xe08efa['rEJkr'](_0xe08efa[_0x3a95('0x1f', '$93!')], _0x3a95('0x20', '2tx)'))) {
                    var _0x3e599d = _0xe08efa['sEqmt']($, this)['index']();
                    _0xe08efa['sEqmt']($, this)[_0x3a95('0x21', 'hj00')](_0xe08efa[_0x3a95('0x22', 'OJ2t')])[_0x3a95('0x23', '[fVg')]()['removeClass'](_0xe08efa[_0x3a95('0x24', 'z)OK')]);
                    _0xe08efa[_0x3a95('0x25', 'Y0Ne')]($, _0xe08efa[_0x3a95('0x26', 'iBHp')])['eq'](_0x3e599d)[_0x3a95('0x27', 'e3Q(')]()[_0x3a95('0x28', 'IdL2')]()['hide']();
                } else {
                    alert(_0xe08efa['zyEbb']);
                    return;
                }
            });
        },
        'getResentApp': function() {
            var _0x45320f = {
                'qOuVD': 'POST',
                'aQJPM': _0x3a95('0x29', 'OJ2t')
            };
            var _0x286613 = this;
            $[_0x3a95('0x2a', 'Y0Ne')]({
                'type': _0x45320f['qOuVD'],
                'url': _0x45320f['aQJPM'],
                'cache': ![],
                'success': function(_0x38eadf) {
                    var _0x496a55 = {
                        'wRVpL': 'EHz',
                        'DUaTq': _0x3a95('0x2b', 'S0K['),
                        'OHXUN': _0x3a95('0x2c', 'IdL2'),
                        'UmKSx': function _0x68beba(_0x2f2d80, _0x134ec9) {
                            return _0x2f2d80(_0x134ec9);
                        },
                        'WsQdw': _0x3a95('0x2d', '$LpG'),
                        'gpUQo': 'click'
                    };
                    if (_0x496a55[_0x3a95('0x2e', 'w9aA')] !== _0x496a55[_0x3a95('0x2f', 'K7HU')]) {
                        _0x286613[_0x3a95('0x30', 'nUU!')] = _0x38eadf[_0x3a95('0x31', 'OJ2t')];
                        _0x286613[_0x3a95('0x32', 'wvok')] = ![];
                    } else {
                        alert(_0x3a95('0x33', 'iBHp'));
                        $(_0x496a55[_0x3a95('0x34', 'AKzo')])[_0x3a95('0x35', '^kc%')]();
                        _0x496a55[_0x3a95('0x36', 'z)OK')]($, _0x496a55['WsQdw'])[_0x3a95('0x37', 'Y0Ne')](_0x496a55[_0x3a95('0x38', 'V#wN')]);
                    }
                },
                'error': function() {}
            });
        },
        'getDoc': function() {
            var _0xd94fc3 = {
                'DpyxH': _0x3a95('0x39', '$93!'),
                'XMiHn': _0x3a95('0x3a', 'cOV#'),
                'DNghD': _0x3a95('0x3b', 'VtQ$')
            };
            var _0x29bd87 = this;
            $[_0x3a95('0x3c', '[fVg')]({
                'type': _0xd94fc3[_0x3a95('0x3d', 'V[T$')],
                'url': _0xd94fc3['XMiHn'],
                'cache': ![],
                'success': function(_0x286085) {
                    _0x29bd87['doclist_0'] = _0x286085['data'];
                },
                'error': function() {
                    var _0x485d46 = {
                        'DGyZx': function _0x338a18(_0x2bd80f, _0x1c21a5) {
                            return _0x2bd80f === _0x1c21a5;
                        },
                        'nTWVj': function _0x2f1c6b(_0x2bcbe1, _0x111306) {
                            return _0x2bcbe1(_0x111306);
                        },
                        'fGnBt': _0x3a95('0x3e', '2tx)')
                    };
                    if (_0x485d46[_0x3a95('0x3f', 'VtQ$')]('LkK', _0x3a95('0x40', '[fVg'))) {} else {
                        _0x485d46['nTWVj'](alert, _0x485d46[_0x3a95('0x41', 'R)sU')]);
                        return;
                    }
                }
            });
            $[_0x3a95('0x42', 'TP%q')]({
                'type': _0xd94fc3[_0x3a95('0x43', 'KSZj')],
                'url': _0xd94fc3[_0x3a95('0x44', '3R5A')],
                'cache': ![],
                'success': function(_0x199a5c) {
                    _0x29bd87['doclist_1'] = _0x199a5c['data'];
                },
                'error': function() {}
            });
            $[_0x3a95('0x45', 'YUOW')]({
                'type': _0x3a95('0x46', 'e3Q('),
                'url': _0x3a95('0x47', 'YUOW'),
                'cache': ![],
                'success': function(_0xc00f6e) {
                    var _0x54f2ea = {
                        'llcXw': function _0x410f8c(_0x2175bc, _0x1925b0) {
                            return _0x2175bc !== _0x1925b0;
                        },
                        'kSHlF': _0x3a95('0x48', 'S0K[')
                    };
                    if (_0x54f2ea[_0x3a95('0x49', 'OJ2t')](_0x54f2ea[_0x3a95('0x4a', 'VtQ$')], 'LTf')) {
                        _0x29bd87['doclist_2'] = _0xc00f6e[_0x3a95('0x4b', 'nUU!')];
                    } else {}
                },
                'error': function() {
                    if ('xoq' === _0x3a95('0x4c', 'PH8K')) {} else {}
                }
            });
        }
    },
    'created': function() {},
    'mounted': function() {
        this[_0x3a95('0x4d', 'KCbE')]();
        this[_0x3a95('0x4e', 'e3Q(')]();
    }
};
vm = new Vue({
    'el': _0x3a95('0x4f', '$93!'),
    'components': {
        'Encapsulation': Encapsulation
    }
});
$(_0x3a95('0x50', 'XT(C'))['click'](function() {
    var _0x312bf7 = {
        'azezk': function _0x1a9307(_0x1029d1, _0x56319f) {
            return _0x1029d1 != _0x56319f;
        },
        'SpTpd': function _0x2c548d(_0x3c5cac, _0x6ea460) {
            return _0x3c5cac(_0x6ea460);
        },
        'CVhvX': _0x3a95('0x51', 'RyDa'),
        'owdlK': _0x3a95('0x52', '[fVg'),
        'fzEdc': _0x3a95('0x53', 'K7HU'),
        'saWuo': _0x3a95('0x54', 'iBHp'),
        'BKIcf': function _0x1b697d(_0x332c29, _0x280881) {
            return _0x332c29(_0x280881);
        },
        'zvscT': function _0xfaa50e(_0x6e1462, _0x4785a8) {
            return _0x6e1462(_0x4785a8);
        },
        'JUNTe': _0x3a95('0x55', 'iBHp')
    };
    if (_0x312bf7['azezk'](_0x312bf7[_0x3a95('0x56', 'WIsr')]($, _0x312bf7[_0x3a95('0x57', 'TP%q')])['val'](), $('#password2')[_0x3a95('0x58', 'OJ2t')]())) {
        _0x312bf7['SpTpd'](alert, _0x312bf7['owdlK']);
        return;
    }
    $[_0x3a95('0x59', 'ye29')]({
        'type': _0x312bf7['fzEdc'],
        'url': _0x312bf7[_0x3a95('0x5a', '[s0D')],
        'cache': ![],
        'data': {
            'username': _0x312bf7['BKIcf']($, '#loginName')['val'](),
            'password': _0x312bf7[_0x3a95('0x5b', 'eA]R')]($, _0x312bf7[_0x3a95('0x5c', 'Y0Ne')])['val'](),
            'inviter': localStorage[_0x3a95('0x5d', 'Y0Ne')](_0x312bf7[_0x3a95('0x5e', 'IdL2')])
        },
        'success': function(_0xc823a1) {
            var _0x58c1d8 = {
                'aqmrQ': function _0x7cbb83(_0x301628, _0x514ae3) {
                    return _0x301628 === _0x514ae3;
                },
                'KLIoU': _0x3a95('0x5f', 'n]!E'),
                'LENhk': function _0x1872fa(_0x13a86d, _0x3cc3f0) {
                    return _0x13a86d == _0x3cc3f0;
                },
                'OZKPE': function _0x1a4604(_0x4cf48b, _0x3ea622) {
                    return _0x4cf48b !== _0x3ea622;
                },
                'BwyrN': _0x3a95('0x60', 'K7HU'),
                'fVORK': _0x3a95('0x61', 'Z$1p'),
                'YfNyU': _0x3a95('0x62', 'NCYy'),
                'iDEQR': function _0x1c9132(_0xae5313, _0x3b1299) {
                    return _0xae5313(_0x3b1299);
                },
                'HYmEd': '注册成功',
                'SWrCb': function _0x1dbef7(_0x3c2301, _0x9fba06) {
                    return _0x3c2301(_0x9fba06);
                },
                'DqPtv': function _0x337778(_0x2a3720, _0x19000f) {
                    return _0x2a3720(_0x19000f);
                },
                'BaSLM': '.loginModal',
                'YugYy': _0x3a95('0x63', 'nUU!')
            };
            if (_0x58c1d8[_0x3a95('0x64', 'r@Vr')](_0x3a95('0x65', 'UdR6'), _0x58c1d8['KLIoU'])) {
                var _0x10bb1f = this;
                $[_0x3a95('0x66', 'FOR0')]({
                    'type': _0x3a95('0x67', 'ye29'),
                    'url': '/getlist.php',
                    'cache': ![],
                    'success': function(_0x26066e) {
                        _0x10bb1f[_0x3a95('0x68', '[cyM')] = _0x26066e[_0x3a95('0x69', 'AKzo')];
                        _0x10bb1f['show_loading'] = ![];
                    },
                    'error': function() {}
                });
            } else {
                console['log'](_0xc823a1);
                if (_0x58c1d8[_0x3a95('0x6a', 'w9aA')](_0xc823a1['code'], 0x0)) {
                    if (_0x58c1d8[_0x3a95('0x6b', 'eA]R')](_0x58c1d8[_0x3a95('0x6c', 'V#wN')], _0x58c1d8['BwyrN'])) {
                        content = JSON[_0x3a95('0x6d', 'nUU!')](content);
                    } else {
                        alert(_0x58c1d8['fVORK']);
                    }
                } else {
                    if (_0x58c1d8[_0x3a95('0x6e', 'kd36')](_0x58c1d8[_0x3a95('0x6f', 'NCYy')], _0x3a95('0x70', 'e3Q('))) {
                        window[_0x3a95('0x71', '^kc%')](_0x3a95('0x72', '$LpG'));
                    } else {
                        _0x58c1d8[_0x3a95('0x73', 'KSZj')](alert, _0x58c1d8[_0x3a95('0x74', 'XT(C')]);
                        _0x58c1d8[_0x3a95('0x75', 'nUU!')]($, _0x3a95('0x76', 'YUOW'))[_0x3a95('0x77', 'CUCu')]();
                        _0x58c1d8[_0x3a95('0x78', 'IdL2')]($, _0x58c1d8[_0x3a95('0x79', 'KCbE')])[_0x3a95('0x7a', 'R)sU')](_0x58c1d8['YugYy']);
                    }
                }
            }
        },
        'error': function() {}
    });
});
if (getQueryString(_0x3a95('0x7b', 'Y0Ne')) != '' && getQueryString('from') != null) {
    localStorage['setItem'](_0x3a95('0x7c', 'e3Q('), getQueryString(_0x3a95('0x7d', 'kd36')));
}
function getQueryString(_0x517ea8) {
    var _0x501cb4 = {
        'ybIsA': function _0x173cf5(_0x40134b, _0x117f8d) {
            return _0x40134b + _0x117f8d;
        },
        'yJeFo': '=([^&]*)(&|$)'
    };
    var _0x41c515 = new RegExp(_0x501cb4[_0x3a95('0x7e', 'uHsL')]('(^|&)' + _0x517ea8, _0x501cb4[_0x3a95('0x7f', 'uHsL')]),'i');
    var _0x59edb1 = window[_0x3a95('0x80', 'kd36')]['search'][_0x3a95('0x81', 'OJ2t')](0x1)['match'](_0x41c515);
    if (_0x59edb1 != null) {
        return unescape(_0x59edb1[0x2]);
    }
    return null;
}
$('#loginButton')[_0x3a95('0x82', 'FOR0')](function() {
    var _0x9f075c = {
        'OZfLc': function _0x54dbad(_0x146256, _0x4c6de4) {
            return _0x146256 == _0x4c6de4;
        },
        'AEHrD': _0x3a95('0x83', 'eA]R'),
        'umWXd': function _0x1e2460(_0x2be60a, _0xccf9ea) {
            return _0x2be60a(_0xccf9ea);
        },
        'Cihxo': _0x3a95('0x84', 'RyDa'),
        'lDGLE': function _0x41ac7c(_0x456baf, _0xaa4b00) {
            return _0x456baf === _0xaa4b00;
        },
        'PeDoB': _0x3a95('0x85', 'e3Q('),
        'HmdIp': _0x3a95('0x86', 'z)OK'),
        'AFiDY': 'from_type',
        'kMyMX': _0x3a95('0x87', 'WIsr'),
        'jTnxP': function _0x7dd9ee(_0x39b5a8, _0x4a1b96) {
            return _0x39b5a8(_0x4a1b96);
        }
    };
    if (_0x9f075c[_0x3a95('0x88', 'RyDa')]($(_0x9f075c[_0x3a95('0x89', 'V[T$')])[_0x3a95('0x8a', 'kd36')](), '') || _0x9f075c[_0x3a95('0x8b', 'PH8K')](_0x9f075c[_0x3a95('0x8c', 'VtQ$')]($, _0x9f075c[_0x3a95('0x8d', 'Y0Ne')])[_0x3a95('0x8e', 'WIsr')](), '')) {
        if (_0x9f075c['lDGLE'](_0x9f075c[_0x3a95('0x8f', 'wvok')], _0x3a95('0x90', 'XT(C'))) {
            alert(_0x9f075c['HmdIp']);
            return;
        } else {
            localStorage[_0x3a95('0x91', 'R)sU')](_0x9f075c[_0x3a95('0x92', '[cyM')], _0x9f075c[_0x3a95('0x93', 'nUU!')](getQueryString, _0x9f075c[_0x3a95('0x94', 'OJ2t')]));
        }
    }
    $[_0x3a95('0x95', 'r@Vr')]({
        'type': 'POST',
        'url': '/api/login.php',
        'cache': ![],
        'data': {
            'username': _0x9f075c[_0x3a95('0x96', 'Z$1p')]($, '#login_username')['val'](),
            'password': $(_0x3a95('0x97', 'kd36'))['val']()
        },
        'success': function(_0x51940f) {
            var _0x261067 = {
                'fivjl': 'Tul',
                'jarzb': function _0x3b987d(_0x363b26, _0x1eaef9) {
                    return _0x363b26(_0x1eaef9);
                },
                'HlufR': _0x3a95('0x98', 'r@Vr'),
                'hHSIa': function _0x2dd773(_0x1c9c6b, _0x46b00b) {
                    return _0x1c9c6b !== _0x46b00b;
                },
                'dgDkc': 'Ise',
                'hhRRE': 'dIV',
                'PogWC': function _0x7a776e(_0x28b186, _0x52f924, _0x531248) {
                    return _0x28b186(_0x52f924, _0x531248);
                },
                'afzve': _0x3a95('0x99', 'KCbE'),
                'GoQHm': 'true',
                'MZMMO': function _0x3b7913(_0x49033d, _0x4c9bae, _0x529840) {
                    return _0x49033d(_0x4c9bae, _0x529840);
                },
                'lFFnB': _0x3a95('0x9a', '$93!'),
                'ggGsT': function _0x4902a3(_0x7882c0, _0x3e1a31, _0x5361f4) {
                    return _0x7882c0(_0x3e1a31, _0x5361f4);
                },
                'UeOlt': _0x3a95('0x9b', 'TP%q'),
                'bfHrL': 'forceshare_login_token',
                'pwlgx': function _0x227d72(_0x1552af, _0x9561f6, _0x466d83) {
                    return _0x1552af(_0x9561f6, _0x466d83);
                },
                'yrGcX': _0x3a95('0x9c', '$93!')
            };
            if (_0x3a95('0x9d', 'tFHw') === _0x261067[_0x3a95('0x9e', 'AKzo')]) {
                console[_0x3a95('0x9f', 'KSZj')](XMLHttpRequest['status']);
                console['log'](XMLHttpRequest['readyState']);
                console[_0x3a95('0xa0', '$93!')](textStatus);
            } else {
                console[_0x3a95('0xa1', 'n]!E')](_0x51940f);
                if (_0x51940f[_0x3a95('0xa2', '2tx)')] == 0x0) {
                    _0x261067[_0x3a95('0xa3', 'z)OK')](alert, _0x261067[_0x3a95('0xa4', 'IdL2')]);
                } else {
                    if (_0x261067[_0x3a95('0xa5', 'V#wN')](_0x261067[_0x3a95('0xa6', 'n]!E')], _0x261067['hhRRE'])) {
                        _0x261067[_0x3a95('0xa7', 'V[T$')](setSession, _0x261067['afzve'], _0x261067[_0x3a95('0xa8', 'hj00')]);
                        _0x261067[_0x3a95('0xa9', '3R5A')](setSession, _0x261067[_0x3a95('0xaa', 'n]!E')], _0x51940f['id']);
                        _0x261067[_0x3a95('0xab', 'n]!E')](setSession, _0x261067[_0x3a95('0xac', 'Z$1p')], _0x51940f[_0x3a95('0xad', 'eA]R')]);
                        _0x261067[_0x3a95('0xae', 'S0K[')](setSession, _0x261067[_0x3a95('0xaf', 'TP%q')], _0x51940f[_0x3a95('0xb0', 'CUCu')]);
                        _0x261067[_0x3a95('0xb1', 'Y0Ne')](setSession, _0x261067[_0x3a95('0xb2', '[fVg')], _0x51940f[_0x3a95('0xb3', 'eA]R')]);
                        location['href'] = _0x51940f[_0x3a95('0xb4', 'hj00')];
                    } else {}
                }
            }
        },
        'error': function(_0x5b67a0, _0x30108d, _0x1afd44) {
            var _0x18d120 = {
                'gYmiJ': function _0x2816b7(_0x24314e, _0x56a4bb) {
                    return _0x24314e !== _0x56a4bb;
                },
                'dhTVT': 'kSN',
                'DHAyS': 'Hou'
            };
            if (_0x18d120[_0x3a95('0xb5', '4jIS')](_0x18d120[_0x3a95('0xb6', 'hj00')], _0x18d120['DHAyS'])) {
                console[_0x3a95('0xb7', 'YUOW')](_0x5b67a0['status']);
                console[_0x3a95('0xb8', 'RyDa')](_0x5b67a0[_0x3a95('0xb9', 'Z$1p')]);
                console[_0x3a95('0xba', 'K7HU')](_0x30108d);
            } else {}
        }
    });
});
function setSession(_0x726559, _0x3cd80a) {
    var _0x274c7d = {
        'ihVzu': function _0x2a1cba(_0x5a35e2, _0x81e403) {
            return _0x5a35e2 !== _0x81e403;
        },
        'NFqWV': _0x3a95('0xbb', 'UdR6')
    };
    if (!_0x726559)
        return;
    if (_0x274c7d[_0x3a95('0xbc', '[hBn')](typeof _0x3cd80a, _0x274c7d[_0x3a95('0xbd', 'PH8K')])) {
        _0x3cd80a = JSON[_0x3a95('0xbe', '[s0D')](_0x3cd80a);
    }
    window[_0x3a95('0xbf', 'eA]R')]['setItem'](_0x726559, _0x3cd80a);
}
function getSession(_0x438e9c) {
    if (!_0x438e9c)
        return;
    return window['sessionStorage']['getItem'](_0x438e9c);
}
function removeSession(_0x170b49) {
    if (!_0x170b49)
        return;
    window['sessionStorage'][_0x3a95('0xc0', 'z)OK')](_0x170b49);
}
document[_0x3a95('0xc1', 'tFHw')] = function mdClick(_0x52f0b7) {
    var _0x3a0910 = {
        'iOgOm': function _0x2c91b7(_0xc37b39, _0x3ee227) {
            return _0xc37b39 == _0x3ee227;
        },
        'LcxHr': function _0x1288f4(_0x201e82, _0x3971d2) {
            return _0x201e82 === _0x3971d2;
        },
        'EgIhx': _0x3a95('0xc2', 'YUOW'),
        'Zjwto': 'ACd'
    };
    var _0x521be9 = _0x52f0b7 || window[_0x3a95('0xc3', 'eA]R')] || arguments['callee']['caller']['arguments'][0x0];
    if (_0x3a0910[_0x3a95('0xc4', 'ym77')](_0x521be9[_0x3a95('0xc5', 'KSZj')], 0x2) || _0x521be9['button'] == 0x3) {
        if (_0x3a0910['LcxHr'](_0x3a0910[_0x3a95('0xc6', '2tx)')], _0x3a0910[_0x3a95('0xc7', 'Y0Ne')])) {} else {}
    }
}
;
document['oncontextmenu'] = new Function('return\x20false;');
document[_0x3a95('0xc8', 'KCbE')] = document[_0x3a95('0xc9', '[fVg')] = document['onkeypress'] = function(_0x252a2f) {
    var _0x19150f = {
        'syBGL': function _0x5c514f(_0x3d8a4b, _0xcaa046) {
            return _0x3d8a4b == _0xcaa046;
        },
        'Dfpzy': function _0x46fa3b(_0x422a0f, _0x524ae5) {
            return _0x422a0f !== _0x524ae5;
        },
        'UnYRa': _0x3a95('0xca', 'Y0Ne'),
        'PRcEI': _0x3a95('0xcb', '[s0D')
    };
    var _0x3b9dd1 = _0x252a2f || window['event'] || arguments['callee'][_0x3a95('0xcc', 'tFHw')]['arguments'][0x0];
    if (_0x3b9dd1 && _0x19150f['syBGL'](_0x3b9dd1['keyCode'], 0x7b)) {
        if (_0x19150f[_0x3a95('0xcd', 'S0K[')](_0x19150f[_0x3a95('0xce', 'r@Vr')], 'eZo')) {
            _0x3b9dd1[_0x3a95('0xcf', 'UdR6')] = ![];
            return ![];
        } else {
            if (!name)
                return;
            if (typeof content !== _0x19150f[_0x3a95('0xd0', 'S0K[')]) {
                content = JSON[_0x3a95('0xd1', 'OJ2t')](content);
            }
            window[_0x3a95('0xd2', 'V#wN')][_0x3a95('0xd3', 'K7HU')](name, content);
        }
    }
}
;
window['onresize'] = function(_0x3776bb) {
    _0x3776bb[_0x3a95('0xd4', 'RyDa')] = ![];
    return ![];
}
;
